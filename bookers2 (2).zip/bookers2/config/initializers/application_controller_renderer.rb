# Be sure to restart your server when you modify this file.

# ActiveSupport::Reloader.to_prepare do
#   ApplicationController.renderer.defaults.merge!(
#     http_host: 'example.org',
#     https: false
#   )
# end

Refile.secret_key = '57493870bff9922f4487cb43ea1d45fcb3da0c8d5b9913f347be58daee9be9e003f0186b2f4af0ce4412454bee7283158e298a1845fe9a04a52ca3adbcf6b8e3'
