class HomesController < ApplicationController
  def top
    p flash
  end
  def about
  end

end
